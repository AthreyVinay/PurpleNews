from django.http import HttpResponse
from django.shortcuts import render
from .models import Message
from django.views.generic import View
from news.articleManager import get_article_list
from django.views.generic import TemplateView
from django.views.generic.edit import FormView




# Create your views here.
from news.forms import CountryCategoryForm


class index(TemplateView, FormView):
    template_name = 'news/index.html'
    form_class = CountryCategoryForm

class articles(TemplateView, FormView):
    template_name = 'news/articles.html'
    form_class = CountryCategoryForm

    def get_country(self, form):
        country = form.country
        context = {"country" : country}
        return context

class summary(TemplateView):
    template_name = 'news/summary.html'