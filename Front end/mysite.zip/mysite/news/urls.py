__author__ = 'Work'

from django.conf.urls import url, include, patterns
from news.views import articles, index, summary
from . import views

urlpatterns = patterns('',
    url(r'^$', index.as_view(), name='index'),
    url(r'articles/$', articles.as_view(), name='articles'),
    url(r'summary/$', summary.as_view(), name='summary'),

)