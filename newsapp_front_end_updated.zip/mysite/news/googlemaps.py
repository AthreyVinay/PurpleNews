__author__ = 'Work'

from googlemaps import GoogleMaps

mapService = GoogleMaps()

